package Lab3submition;

import java.util.Scanner;
public class Lab3 {
    public static void main(String[] args) {
        Scanner inScan = new Scanner(System.in);
        int logBase;
        int x;
        int count = 0;
        int divide;
        do{
            System.out.print("Please enter the log base: ");
            logBase = inScan.nextInt();
            System.out.print("Please enter the int for X: ");
            x = inScan.nextInt();
            divide = x;
            if(logBase > 1 || x > 0) {
                do {
                    divide = divide / logBase;
                    count++;
                } while (logBase <= divide);
                System.out.println("Log base " + logBase + " of " + divide + " is " + count);
            }
        }while (logBase > 1 || x > 0);
    }
}
